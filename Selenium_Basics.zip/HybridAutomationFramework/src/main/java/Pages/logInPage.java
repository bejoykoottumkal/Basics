package Pages;

import Utilities.ExtentReportUtility;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class logInPage {
    WebDriver driver;
    public logInPage(WebDriver driver){
        this.driver =  driver;
    }
    public void login(String username, String password){
        ExtentReportUtility.test.log(Status.INFO, "Entering UserName "+username);
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
        driver.findElement(By.xpath("//input[@name='password']")).clear();
        ExtentReportUtility.test.log(Status.INFO, "Entering Password "+password);
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
        ExtentReportUtility.test.log(Status.INFO, "Clicked on SignIn ");
        driver.findElement(By.xpath("//input[@name='signon']")).click();
    }
    public String getPageURL(){
        return driver.getCurrentUrl();
    }

}
