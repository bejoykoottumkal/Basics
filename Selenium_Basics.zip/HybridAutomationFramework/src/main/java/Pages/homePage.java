package Pages;

import Utilities.ExtentReportUtility;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class homePage {
    WebDriver driver;
    public homePage(WebDriver driver){
        this.driver =  driver;
    }
    public void clickOption(){
        ExtentReportUtility.test.log(Status.INFO, "Successfully Clicked The Selected Option");
        driver.findElement(By.xpath("//area[@alt='Dogs']']")).click();

    }
   public String getPageURL(){
        return driver.getCurrentUrl();
   }
  }

