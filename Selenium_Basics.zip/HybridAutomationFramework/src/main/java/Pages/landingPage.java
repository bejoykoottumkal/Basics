package Pages;

import Utilities.ExtentReportUtility;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class landingPage {
    WebDriver driver;
    public landingPage(WebDriver dvr){
       driver =  dvr;

    }
    public void clickSignIn(){
        ExtentReportUtility.test.log(Status.INFO, "Successfully CLicked SignIn");
        driver.findElement(By.xpath("//a[text()='Sign In']")).click();

    }
}
