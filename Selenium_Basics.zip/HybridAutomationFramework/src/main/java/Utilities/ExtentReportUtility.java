package Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReportUtility {
    public static ExtentSparkReporter spark;
    public static ExtentReports report;
    public static ExtentTest test;

    public static void CreateExtentReportInstance(String className)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS");
        Date now = new Date();
        String timeStamp = sdf.format(now);
        spark = new ExtentSparkReporter("./ExtentReport/"+className+"_"+timeStamp+".html");
        spark.config().setDocumentTitle("ExtentReportSample");
        spark.config().setReportName("ReportSample");
        report = new ExtentReports();
        report.attachReporter(spark);
        test = report.createTest(className);

    }
    public static void GenerateReport(ITestResult result, WebDriver driver) throws IOException
    {

        if (result.getStatus() == ITestResult.SUCCESS) {
            test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " Test Case Passed", ExtentColor.GREEN));

        } else if (result.getStatus() == ITestResult.FAILURE) {

            test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " Test Case Failed", ExtentColor.RED));
            test.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromBase64String(ScreenShotUtility.getScreenShot(driver)).build());

        } else {
            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " Test Case Skipped", ExtentColor.YELLOW));
        }
        report.flush();
    }

    }
