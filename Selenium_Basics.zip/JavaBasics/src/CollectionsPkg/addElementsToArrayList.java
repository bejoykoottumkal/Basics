package CollectionsPkg;

import java.util.ArrayList;
import java.util.Collections;

public class addElementsToArrayList {
    public static void main(String[] args) {
        ArrayList<String> TestL = new ArrayList<>();



        TestL.add("A");
        TestL.add("B");
        TestL.add("C");
        TestL.add("D");
        TestL.add("E");
        TestL.add("F");
        TestL.add("G");
        TestL.add("H");
        TestL.add("I");
        TestL.add("J");
        TestL.add("K");
        TestL.add("L");

        System.out.println("Array List Values are : "+TestL);

        TestL.add(0,"AA");
        TestL.add(10, "AAA");
        TestL.add("M");
        System.out.println("New List Values are : "+TestL);

        TestL.remove("AAA");

        System.out.println(" 1st List Values are : "+TestL);

        TestL.remove(0);

        System.out.println(" 2nd List Values are : "+TestL);

        TestL.set(0,"UpdateA");

        System.out.println(" 3rd List Values are : "+TestL);

        for (String ele:TestL){
            System.out.println(ele);
        }
        System.out.println("fetched Value is  : "+TestL.get(10));
        System.out.println("Size of the list is :"+TestL.size());
        if (TestL.contains("Z")){
            System.out.println("Value Exist");

        }
        else {
            System.out.println("Value not found");
        }
        /*TestL.clear();
        System.out.println("Reset");*/

        Collections.sort(TestL);

        System.out.println("Sorted Values are : "+TestL);
    }


}
