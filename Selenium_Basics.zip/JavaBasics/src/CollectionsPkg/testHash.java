package CollectionsPkg;

import com.sun.source.tree.WhileLoopTree;

import java.util.HashSet;
import java.util.Iterator;

public class testHash {
    public static void main(String[] args) {

        HashSet<String> testHash = new HashSet<>();

        testHash.add("A");
        testHash.add("B");
        testHash.add("C");
        testHash.add("D");
        testHash.add("E");
        testHash.add("A");


        Iterator it = testHash.iterator();
        while (it.hasNext())
        {
            System.out.println(it.next());

        }

    }
}
