package CollectionsPkg;

import java.util.HashMap;
import java.util.Iterator;

public class HashMapSample {
    public static void main(String[] args) {
        HashMap<String,String> newTest = new HashMap<>();

        newTest.put("India","red" );
        newTest.put("USA","blue" );
        newTest.put("Canada","green" );

        String A = newTest.get("0");
        String B = newTest.get("1");
        String C = newTest.get("2");
    for(String X:newTest.keySet()){
        System.out.println(newTest.get(X));
    }

        System.out.println(newTest.size());
    newTest.remove( "India");
        System.out.println(newTest);


    }
}
