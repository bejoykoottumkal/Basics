package CollectionsPkg;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayMerge {
    public static void main(String[] args) {
        String array[] = {"One", "Two", "Three", "Four" };
        ArrayList<String> arrayl= new ArrayList<>();

        Collections.addAll(arrayl, array);
        arrayl.add("new one");

        System.out.println(arrayl);


    }
}
