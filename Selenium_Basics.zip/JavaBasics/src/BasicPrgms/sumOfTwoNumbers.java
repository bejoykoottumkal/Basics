package BasicPrgms;

public class sumOfTwoNumbers {
    public static void main(String[] args) {
        int a=2,b=4,s=0;
        s=a+b;
        System.out.println("sum of the numbers is : "+s );


    }
}
