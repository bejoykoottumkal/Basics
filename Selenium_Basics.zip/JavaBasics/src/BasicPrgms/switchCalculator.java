package BasicPrgms;

public class switchCalculator {
    public static void main(String[] args) {
        String Op = "/";
        int a = 4,b=2,s=0;
        switch (Op)
        {
            case "+":
                s = a+b;
                System.out.println("Sum is : "+s);
                break;
            case "-":
                s=a-b;
                System.out.println("Value is : "+s);
                break;
            case "/":
                s=a/b;
                System.out.println("Value is : "+s);
                break;
            case "*":
                s=a*b;
                System.out.println("Value is : "+s);
                break;
            default:
                System.out.println("Invalid operator");
                break;
        }
    }
}
