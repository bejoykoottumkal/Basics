package BasicPrgms;

public class evenNumbers {
    public static void main(String[] args) {
        int n=1;
        System.out.println("Even Numbers Are : ");
        while (n<=50){
            if(n%2==0)
               /* if(n%2!=0)*/
            {
                System.out.print(n+" ");
            }
            n++;

        }
    }
}
