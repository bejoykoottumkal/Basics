package BasicPrgms;

public class largestOfTwoNumbers {
    public static void main(String[] args) {
        int a=4,b=2;
        if (a>b){
            System.out.println("a is the largest");
        }
        else
        {
            System.out.println("b is largest");
        }
    }
}
